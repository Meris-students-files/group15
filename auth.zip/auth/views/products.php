<?php
?>
<section id="products">
    <div class="container">
        <div class="row products">

        </div>
    </div>
</section>
<script>
    $(function () {
        $.post('/conf.php', { class: 'Product', method: 'read' }, function (data) {
            let products = JSON.parse(data);
            products.forEach(e => {

                console.log(e)
                let images = e.image.split(',');
                console.log(images)
                let str = '';
                images.forEach((img, index) => {
                    str += `<div class="col-3"><img class="w-100" src=${img}></div>`
                });
                console.log(str)
                let div = `
                <div class="col col-12 col-sm-4 col-md-3">
                <div class="card">
                    <img class="card-img-top" src="/${images[0]}" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title">${e.title}</h5>
                        <p class="card-text">${e.description}</p>
                        <a href="#" class="btn btn-primary">Add to Cart</a>
                        <a href="/product/${e.id}" class="btn btn-primary">View product</a>
                        <div class="row">
                            ${str}
                        </div>
                    </div>
                </div>
                </div>
            `
                $('.products').append(div);
            });



        })
    })
</script>