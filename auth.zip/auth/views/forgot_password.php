<form action="/" method="POST">
    <input type="email" name="email" placeholder='email@example.com'>
    <input type="hidden" name="class" value="Auth">
    <input type="hidden" name="method" value='forgot_password'>
    <input type="submit">
</form>