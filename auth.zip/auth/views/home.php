
<?
if(isset($_SERVER['id'])){?>
    <h1>Welcome</h1>
<?}
?>