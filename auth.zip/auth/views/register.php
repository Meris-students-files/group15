<form id="register_form">
    <input type="text" name="username" placeholder="username">
    <input type="email" name="email" placeholder='email'>
    <input type="password" name="password" placeholder='password'>
    <input type="text" name="full_name" placeholder='Name and Surname'>
    <input type="hidden" name="class" value="Auth">
    <input type="hidden" name="method" value='register'>
    <input type="submit">
</form>