
<form action="/">
    <input type="password" name='password1'>
    <input type="password" name='password2'>
    <input type="hidden" name='class' value="Auth">
    <input type="hidden" name='method' value="change_password">
    <input type="submit">
</form>